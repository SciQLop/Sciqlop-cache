#include "../hedley.h"

HEDLEY_DIAGNOSTIC_DISABLE_UNUSED_FUNCTION

int square(int x) {
  return x * x;
}

int main(void) {
  return 0;
}
